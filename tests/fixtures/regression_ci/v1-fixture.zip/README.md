# CounterForge portable correctness regression

Verify sha256sums.txt before trusting extracted code. Install the pinned requirements
in an isolated Python 3.12 environment OUTSIDE this extracted directory:
python -m venv /tmp/counterforge-runner-venv
/tmp/counterforge-runner-venv/bin/python -m pip install -r requirements.txt
Use that environment's Python for the commands below. Extra bundle files are rejected.

Offline historical replay (does not call a provider):
python runner/target_adapter.py --replay-recorded
COUNTERFORGE_RUN_MODE=replay python -m pytest -q tests

The historical wrong result MUST fail with expected/actual; replay is not live reproduction.
LOCAL_FIXTURE bundles contain simulated evidence, never a real model discovery.
For fixture self-tests only: COUNTERFORGE_RUN_MODE=fixture COUNTERFORGE_FIXTURE_COUNT=5 python -m pytest -q tests

Explicit authorized live run (REAL_PROVIDER bundles only): set MODEL_API_KEY in the
environment, then python runner/target_adapter.py --live or
COUNTERFORGE_RUN_MODE=live python -m pytest -q tests.
One call maximum, 45 second timeout, at most 4096 completion tokens, no retries.
Provider-reported usage is printed; missing usage/cost remains unknown.
The assertion always compares actual count with expected ground truth.
Transport, refusal, parser, format and integrity failures are execution errors.
Provider-managed behavior may change. Human demo approval is separate from export.
