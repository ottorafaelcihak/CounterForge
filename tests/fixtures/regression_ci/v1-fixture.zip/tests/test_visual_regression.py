"""Portable correctness assertion; opt in via COUNTERFORGE_RUN_MODE."""
import importlib.util
import os
from pathlib import Path


def test_visual_regression():
    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location("counterforge_runner", root / "runner/target_adapter.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    runner.run(root, os.environ.get("COUNTERFORGE_RUN_MODE", ""), os.environ.get("COUNTERFORGE_FIXTURE_COUNT"))
